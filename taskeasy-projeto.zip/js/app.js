'use strict';

// Chave única no LocalStorage
const STORAGE_KEY = 'taskeasy.tasks.v1';

/** Utilidades **/
const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
const qs = (sel, el = document) => el.querySelector(sel);
const qsa = (sel, el = document) => [...el.querySelectorAll(sel)];

/** Persistência **/
const storage = {
  load() {
    try { return JSON.parse(localStorage.getItem(STORAGE_KEY)) || []; }
    catch { return []; }
  },
  save(tasks) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
  }
};

/** Estado da aplicação **/
const state = {
  tasks: storage.load(),
  filter: 'all' // all | active | completed
};

/** Operações de domínio **/
const Task = {
  create({ title, due }) {
    return {
      id: uid(),
      title: title.trim(),
      completed: false,
      createdAt: new Date().toISOString(),
      due: due || null
    };
  },
  toggle(id){
    const t = state.tasks.find(t => t.id === id);
    if (t){ t.completed = !t.completed; storage.save(state.tasks); }
  },
  remove(id){
    state.tasks = state.tasks.filter(t => t.id !== id);
    storage.save(state.tasks);
  },
  clearCompleted(){
    state.tasks = state.tasks.filter(t => !t.completed);
    storage.save(state.tasks);
  }
};

/** Renderização **/
function render(){
  const list = qs('#task-list');
  list.innerHTML = '';

  const tasks = getFiltered();
  if(tasks.length === 0){
    const li = document.createElement('li');
    li.className = 'task';
    li.innerHTML = '<span class=\"meta\">Nenhuma tarefa para exibir.</span>';
    list.appendChild(li);
  } else {
    for (const t of tasks){
      list.appendChild(renderItem(t));
    }
  }
  updateCounts();
  updateFilterChips();
}

function renderItem(t){
  const li = document.createElement('li');
  li.className = 'task' + (t.completed ? ' completed' : '');
  li.setAttribute('data-id', t.id);

  // Checkbox
  const cb = document.createElement('input');
  cb.type = 'checkbox';
  cb.checked = t.completed;
  cb.setAttribute('aria-label', 'Concluir tarefa');
  cb.addEventListener('change', () => { Task.toggle(t.id); render(); });

  // Conteúdo
  const content = document.createElement('div');
  const title = document.createElement('div');
  title.className = 'title';
  title.textContent = t.title;

  const meta = document.createElement('div');
  meta.className = 'meta';
  meta.textContent = formatMeta(t);

  content.appendChild(title);
  content.appendChild(meta);

  // Ações
  const actions = document.createElement('div');
  actions.className = 'actions';

  const btnDelete = document.createElement('button');
  btnDelete.className = 'btn danger';
  btnDelete.type = 'button';
  btnDelete.setAttribute('aria-label', 'Remover tarefa');
  btnDelete.textContent = 'Excluir';
  btnDelete.addEventListener('click', () => { Task.remove(t.id); render(); });

  actions.appendChild(btnDelete);

  // Montagem
  li.appendChild(cb);
  li.appendChild(content);
  li.appendChild(actions);

  return li;
}

function formatMeta(t){
  const created = new Date(t.createdAt);
  const createdStr = created.toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' });
  const dueStr = t.due ? ` · prazo: ${new Date(t.due).toLocaleDateString('pt-BR')}` : '';
  return `criada: ${createdStr}${dueStr}`;
}

function getFiltered(){
  if (state.filter === 'active') return state.tasks.filter(t => !t.completed);
  if (state.filter === 'completed') return state.tasks.filter(t => t.completed);
  return state.tasks;
}

function updateCounts(){
  const all = state.tasks.length;
  const active = state.tasks.filter(t => !t.completed).length;
  const completed = all - active;
  qs('#count-all').textContent = all;
  qs('#count-active').textContent = active;
  qs('#count-completed').textContent = completed;
}

function updateFilterChips(){
  qsa('.chip').forEach(ch => {
    const on = ch.getAttribute('data-filter') === state.filter;
    ch.classList.toggle('is-active', on);
    ch.setAttribute('aria-selected', on ? 'true' : 'false');
  });
}

/** Eventos **/
function bindEvents(){
  // Criar tarefa
  qs('#form-create').addEventListener('submit', (e) => {
    e.preventDefault();
    const title = qs('#title').value;
    const due = qs('#due').value || null;
    if (!title.trim()) return;
    state.tasks.unshift(Task.create({ title, due }));
    storage.save(state.tasks);
    e.target.reset();
    qs('#title').focus();
    render();
  });

  // Filtros
  qsa('.chip').forEach(ch => ch.addEventListener('click', () => {
    state.filter = ch.getAttribute('data-filter');
    render();
  }));

  // Remover concluídas
  qs('#clear-completed').addEventListener('click', () => {
    Task.clearCompleted();
    render();
  });

  // Exportar JSON
  qs('#export-json').addEventListener('click', () => {
    const blob = new Blob([JSON.stringify(state.tasks, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'taskeasy-export.json';
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  });
}

/** Inicialização **/
function init(){
  bindEvents();
  render();
}

document.addEventListener('DOMContentLoaded', init);
