# TaskEasy — Lista de Tarefas Pessoais

Aplicação web simples para gerenciar tarefas do dia a dia. **Iteração 1**: app 100% client-side, persistência via **LocalStorage**, deploy em **hosting estático** (Vercel/Netlify/GitHub Pages).

## ✨ Funcionalidades
- Adicionar tarefas com título (obrigatório) e prazo (opcional)
- Listar, concluir e excluir tarefas
- Filtros: todas, ativas e concluídas
- Contadores e exportação para JSON
- Persistência local (LocalStorage)

## 🧱 Arquitetura
- Front-end estático: `index.html`, `css/style.css`, `js/app.js`
- Sem backend nesta iteração

## 🚀 Como executar localmente
1. Baixe os arquivos ou clone o repositório.
2. Abra `index.html` no navegador.

> Dica: para evitar problemas de caminho, você pode servir o projeto com um servidor estático simples (ex.: `npx serve` ou extensão “Live Server” do VS Code).

## ☁️ Deploy (3 opções)
### Opção A — **Vercel**
1. Crie uma conta em https://vercel.com e conecte seu GitHub.
2. Clique em **New Project** → **Import** `taskeasy-projeto`.
3. Build & Output: _framework = Other_, _output dir = raiz_ (não precisa build).
4. Deploy. Seu link ficará como `https://taskeasy.vercel.app` (ou similar).

### Opção B — **Netlify**
1. Acesse https://app.netlify.com → **Add new site** → **Import from Git**.
2. Conecte ao repositório e deploy. Sem build.

### Opção C — **GitHub Pages**
1. No repositório: **Settings** → **Pages** → _Deploy from branch_.
2. Branch: `main`, pasta `/root`. Salve.
3. O link será `https://SEU_USUARIO.github.io/taskeasy-projeto/`.

## 📜 Licença
MIT (opcional)
